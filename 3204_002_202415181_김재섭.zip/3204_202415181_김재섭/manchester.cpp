

#include <iostream>
#include <string>
#include <vector>

using namespace std;

const int SEG_WIDTH = 3;      // 반 비트(half-bit) 한 칸의 출력 폭
const int BITS_PER_ROW = 8;   // 파형 한 줄에 그릴 비트 수

// 인코딩: 비트 1개 -> 신호 레벨 2개 (반주기씩)
vector<char> encodeManchester(const string& bits) {
    vector<char> signal;
    for (char b : bits) {
        if (b == '1') {          // 1 : Low -> High
            signal.push_back('L');
            signal.push_back('H');
        } else {                 // 0 : High -> Low
            signal.push_back('H');
            signal.push_back('L');
        }
    }
    return signal;
}


void drawWaveformRow(const string& bits, const vector<char>& signal, size_t startBit, size_t bitCount) {
    size_t startSeg = startBit * 2;
    size_t segCount = bitCount * 2;
    size_t width = segCount * (SEG_WIDTH + 1) + 1;

    string bitRow(width, ' ');    // 비트 값
    string clkRow(width, ' ');    // 비트 경계 표시
    string top(width, ' ');       // High 레벨
    string mid(width, ' ');       // 전이선
    string bot(width, ' ');       // Low 레벨

    for (size_t s = 0; s < segCount; ++s) {
        size_t col = s * (SEG_WIDTH + 1);       // 경계 열
        char level = signal[startSeg + s];

        // 경계에서 레벨이 바뀌면 세로선
        if (startSeg + s > 0 && signal[startSeg + s - 1] != level) {
            mid[col] = '|';
            bot[col] = '|';
        }

        // 반 비트 구간 수평선
        for (int k = 1; k <= SEG_WIDTH; ++k) {
            if (level == 'H') top[col + k] = '_';
            else              bot[col + k] = '_';
        }

        // 비트 경계 / 라벨
        if (s % 2 == 0) {
            clkRow[col] = ':';
            bitRow[col + SEG_WIDTH + 1] = bits[startBit + s / 2];
        }
    }
    clkRow[width - 1] = ':';

    cout << "  bit  " << bitRow << "\n";
    cout << "       " << clkRow << "\n";
    cout << "  H    " << top << "\n";
    cout << "       " << mid << "\n";
    cout << "  L    " << bot << "\n\n";
}

void drawWaveform(const string& bits, const vector<char>& signal) {
    for (size_t i = 0; i < bits.size(); i += BITS_PER_ROW) {
        size_t n = min((size_t)BITS_PER_ROW, bits.size() - i);
        drawWaveformRow(bits, signal, i, n);
    }
}

int main() {
    cout << "==========================================================\n";
    cout << "            Manchester Encoding Program\n";
    cout << "----------------------------------------------------------\n";
    cout << "   1 : Low  -> High\n";
    cout << "   0 : High -> Low\n";
    cout << "==========================================================\n";

    // 비트열 입력 (0과 1만 허용)
    string bits;
    while (true) {
        cout << "\n  Enter a bit string (0/1): ";
        string line;
        if (!getline(cin, line)) return 0;

        bits.clear();
        bool valid = true;
        for (char c : line) {
            if (c == '0' || c == '1') bits += c;
            else if (c == ' ' || c == '\r') continue;
            else { valid = false; break; }
        }
        if (valid && !bits.empty()) break;
        cout << "  [Error] Use only 0 and 1.\n";
    }

    vector<char> signal = encodeManchester(bits);

    // 인코딩 표
    cout << "\n  [Encoding table]\n";
    cout << "   Bit | 1st half | 2nd half | Transition\n";
    cout << "  -----+----------+----------+------------\n";
    for (size_t i = 0; i < bits.size(); ++i) {
        char a = signal[2 * i], b = signal[2 * i + 1];
        cout << "    " << bits[i] << "  |    " << a << "     |    " << b
             << "     | " << (a == 'L' ? "Low -> High" : "High -> Low") << "\n";
    }

    // 신호열
    cout << "\n  Signal: ";
    for (size_t i = 0; i < signal.size(); ++i) {
        cout << signal[i];
        if (i % 2 == 1 && i + 1 < signal.size()) cout << ' ';
    }

    // 파형
    cout << "\n\n  [Waveform]\n\n";
    drawWaveform(bits, signal);

    cout << "  Press Enter to close...";
    string dummy;
    getline(cin, dummy);
    return 0;
}
